package com.example.inventory_service.entity;

import java.time.LocalDateTime;

public interface LedgerView {

  String getTransactionType();

  Integer getCrateCount();

  Integer getBalance();


  LocalDateTime getTransactionDate();

}
