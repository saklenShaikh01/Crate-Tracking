package com.example.inventory_service.Dto;

import com.example.inventory_service.enums.ActionType;
import com.example.inventory_service.enums.PersonType;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CrateRequest {

  private Long personId;
  private String name;
  private PersonType personType;
  private ActionType action;
  private int crateCount;

  private int balance;

  // getters setters
}
